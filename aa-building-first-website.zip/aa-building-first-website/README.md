# aa-building-first-website
Project built as an app academy open assignment, it´s a simple static website.
